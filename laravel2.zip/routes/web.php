<?php

include('admin.php');
include('site.php');
