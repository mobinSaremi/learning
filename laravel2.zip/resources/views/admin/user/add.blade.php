@extends('layouts.admin.master')
@section('content')
@section('title')
افزودن ادمین
@stop
<form method="POST" action="{{route('admin.user.list.add')}}"  enctype="multipart/form-data">
    @csrf
@include('admin.user.form')
</form>
@stop