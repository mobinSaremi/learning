@extends('layouts.admin.master')
@section('content')
@section('title')
ویرایش 
@stop
<form method="POST" action="{{route('admin.article_category.list.edit',['id'=>$data->id])}}"  enctype="multipart/form-data">
    @csrf
@include('admin.article-category.form')
</form>

@stop