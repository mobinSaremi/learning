@extends('layouts.admin.master')
@section('content')
@section('title')
ویرایش پیشنهاد
@stop
<form method="POST" action="{{route('admin.suggestion.list.edit',['id'=>$data->id])}}"  enctype="multipart/form-data">
    @csrf
@include('admin.suggestion.form')
</form>

@stop