@extends('layouts.admin.master')
@section('content')
@section('title')
ویرایش عضو
@stop
<form method="POST" action="{{route('admin.personal.list.edit',['id'=>$data->id])}}"  enctype="multipart/form-data">
    @csrf
@include('admin.personal.form')
</form>

@stop