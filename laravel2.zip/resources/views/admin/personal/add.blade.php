@extends('layouts.admin.master')
@section('content')
@section('title')
افزودن عضو
@stop
<form method="POST" action="{{route('admin.personal.list.add')}}"  enctype="multipart/form-data">
    @csrf
@include('admin.personal.form')
</form>
@stop