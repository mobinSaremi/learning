<script src="{{asset('assets/site/js/jquery.min.js')}}"></script>
		<script src="{{asset('assets/site/js/popper.min.js')}}"></script>
		<script src="{{asset('assets/site/js/bootstrap.min.js')}}"></script>
		<script src="{{asset('assets/site/js/aos.js')}}"></script>
		<script src="{{asset('assets/site/js/perfect-scrollbar.jquery.min.js')}}"></script>
		<script src="{{asset('assets/site/js/owl.carousel.min.js')}}"></script>
		<script src="{{asset('assets/site/js/jquery-rating.js')}}"></script>
		<script src="{{asset('assets/site/js/slick.js')}}"></script>
		<script src="{{asset('assets/site/js/slider-bg.js')}}"></script>
		<script src="{{asset('assets/site/js/lightbox.js')}}"></script> 
		<script src="{{asset('assets/site/js/imagesloaded.js')}}"></script>
		<script src="{{asset('assets/site/js/isotope.min.js')}}"></script>
		<script src="{{asset('assets/site/js/custom.js')}}"></script>
		