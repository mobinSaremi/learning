<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
        <title>@yield('title')</title>
		
        <!-- All Plugins Css -->
        <link href="{{asset('assets/site/css/plugins.css')}}" rel="stylesheet">
        <script  src="{{asset('assets/site/js/sweetalert.min.js')}}"></script>
        <!-- Custom CSS -->
        <link href="{{asset('assets/site/css/styles.css')}}" rel="stylesheet">
    </head>