<section class="bg--dark">
				<div class="container">
				
					<div class="row">
						<div class="col text-center">
							<div class="sec-heading mx-auto">
								<h2 class="font-2 font-normal">  </h2>
								<p></p>
							</div>
						</div>
					</div>
					
					<div class="row">
						<?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-4 col-sm-6 mb-4">
							<div class="our-team" data-aos="fade-up" data-aos-duration="1200">
								<img src="<?php echo e(asset('assets/upload/'.$personal->image)); ?>" class="img-responsive" alt="" />
								<h4><a href="landing-one.html#"><?php echo e($personal->name); ?> </a></h4>
								<span class="designation bg-success"><?php echo e($personal->post); ?> </span>
								<p><?php echo $personal->description; ?></p>
								<ul class="our-team-profile">
									<li><a href="<?php echo e($personal->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
									<li><a href="<?php echo e($personal->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
									<li><a href="<?php echo e($personal->linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="<?php echo e($personal->instagram); ?>"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				
				</div>
			</section><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/site/blocks/personal.blade.php ENDPATH**/ ?>