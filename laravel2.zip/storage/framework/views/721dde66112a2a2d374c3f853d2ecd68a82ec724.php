
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
ویرایش پیشنهاد
<?php $__env->stopSection(); ?>
<form method="POST" action="<?php echo e(route('suggestion.edit',['id'=>$data->id])); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<?php echo $__env->make('admin.suggestion.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/suggestion/edit.blade.php ENDPATH**/ ?>