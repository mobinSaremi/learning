
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->startSection('title'); ?>
افزودن خبر
<?php $__env->stopSection(); ?>
<link href="<?php echo e(asset('assets/admin/css/jalalidatepicker.css')); ?>" rel="stylesheet">
    <style>
        jdp-container{
            z-index: 9999;
        }
    </style>
    <?php $__env->stopSection(); ?>
<form method="POST" action="<?php echo e(route('news.add')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<?php echo $__env->make('admin.news.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<script src="<?php echo e(asset('assets/admin/js/jalalidatepicker.js')); ?>"></script>
    <script>
        jalaliDatepicker.startWatch({
            separatorChar: "/",
            minDate: "attr",
            maxDate: "attr",
            changeMonthRotateYear: true,
            showTodayBtn: true,
            showEmptyBtn: true
        });
        //flatpickr("[data-jdp]");
        document.getElementById("aaa").addEventListener("jdp:change", function(e) {
            console.log(e)
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/news/add.blade.php ENDPATH**/ ?>