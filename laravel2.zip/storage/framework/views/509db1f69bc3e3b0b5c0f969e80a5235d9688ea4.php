
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
لیست درخواست تماس باما
<?php $__env->stopSection(); ?>
<div class="container p-2">
    <div class="card mb-5 mb-xl-8">
        <!--begin::Header-->
        <div class="card-header border-0 pt-5">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bold fs-3 mb-1">جدول  تماس باما</span>
            </h3>
           
        </div>
        <!--end::Header-->
        <!--begin::Body-->
        <div class="card-body py-3">
            <!--begin::Table container-->
            <div class="table-responsive">
                <!--begin::Table-->
                <table class="table align-middle gs-0 gy-4">
                    <!--begin::Table head-->
                    <thead>
                        <tr class="fw-bold text-muted bg-light">
                            <th>شماره</th>
                            <th>نام و نام خانوادگی</th>
                            <th> ایمیل</th>
                            <th>موضوع</th>
                            <th>نظر</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>

                        </tr>
                    </thead>
                    <!--end::Table head-->
                    <!--begin::Table body-->
                    <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($contact->id); ?></td>
                            <td>
                              <?php echo e($contact->name); ?>

                            </td>
                            
                           <td><?php echo e($contact->email); ?></td>
                           <td><?php echo e($contact->subject); ?></td>
                           <td><?php echo e($contact->comment); ?></td>
                            <td>
                            <?php if($contact->status == 1): ?> <label class="text-success" for="">خوانده شده</label> <?php else: ?> <label class="text-danger" for=""> خوانده نشده</label> <?php endif; ?>
                            </td>
                           <td>
                            <a class="btn btn-danger"  onclick="return confirm('آیا از حذف اطلاعات مطمئن هستید؟');" href="<?php echo e(route('admin.contact_us.list.delete',['id'=>$contact->id])); ?>" style="width: 80px;">حذف</a>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                        </tr>
                    </tbody>
                    <!--end::Table body-->
                </table>
                <!--end::Table-->
            </div>
            <!--end::Table container-->
        </div>
        <!--begin::Body-->

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/contact-us/list.blade.php ENDPATH**/ ?>