
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
تکست
<?php $__env->stopSection(); ?>
<form method="POST" action="<?php echo e(route('text',['id'=>@$data->id])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="container">




        <div class="row m-0  w-100">
            <div class="col-12 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">عنوان مقاله </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="blog_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->blog_title); ?>    <?php else: ?> <?php echo e(@old('blog_title')); ?>  <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="fv-row mb-7">
                <label class="fs-6 fw-semibold form-label mt-3">
                    <span>توضیحات مقاله</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                </label>
                <textarea class="form-control  ckeditor" name="blog_description" style="background:darkgray ;"> <?php if(isset($data)): ?> <?php echo e(@$data->blog_description); ?>     <?php else: ?> <?php echo e(@old('blog_description')); ?>       <?php endif; ?></textarea>
            </div>
        </div>

        <hr>

        <div class="row m-0  w-100">
            <div class="col-12 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">عنوان تیم ما </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="personal_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->personal_title); ?>    <?php else: ?> <?php echo e(@old('personal_title')); ?>  <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="fv-row mb-7">
                <label class="fs-6 fw-semibold form-label mt-3">
                    <span>توضیحات تیم ما</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                </label>
                <textarea class="form-control  ckeditor" name="personal_description" style="background:darkgray ;"> <?php if(isset($data)): ?> <?php echo e(@$data->personal_description); ?>     <?php else: ?> <?php echo e(@old('personal_description')); ?>       <?php endif; ?></textarea>
            </div>
        </div>

        <hr>

        <div class="row m-0  w-100">
            <div class="col-12 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">عنوان محصولات </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="product_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->product_title); ?>    <?php else: ?> <?php echo e(@old('product_title')); ?>  <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="fv-row mb-7">
                <label class="fs-6 fw-semibold form-label mt-3">
                    <span>توضیحات محصولات </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                </label>
                <textarea class="form-control  ckeditor" name="product_description" style="background:darkgray ;"> <?php if(isset($data)): ?> <?php echo e(@$data->product_description); ?>     <?php else: ?> <?php echo e(@old('product_description')); ?>       <?php endif; ?></textarea>
            </div>
        </div>

        <hr>

        <div class="row m-0  w-100">
            <div class="col-12 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">عنوان پیشنهادات </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="suggestion_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->suggestion_title); ?>    <?php else: ?> <?php echo e(@old('suggestion_title')); ?>  <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="fv-row mb-7">
                <label class="fs-6 fw-semibold form-label mt-3">
                    <span>توضیحات پیشنهادات </span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                </label>
                <textarea class="form-control  ckeditor" name="suggestion_description" style="background:darkgray ;"> <?php if(isset($data)): ?> <?php echo e(@$data->suggestion_description); ?>     <?php else: ?> <?php echo e(@old('suggestion_description')); ?>       <?php endif; ?></textarea>
            </div>
        </div>
        <div class="row m-0  w-100">
            <div class="save">
                <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
            </div>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/texts/text.blade.php ENDPATH**/ ?>