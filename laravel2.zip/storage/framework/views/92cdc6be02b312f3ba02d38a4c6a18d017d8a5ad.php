<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
        <title><?php echo $__env->yieldContent('title'); ?></title>
		
        <!-- All Plugins Css -->
        <link href="<?php echo e(asset('assets/site/css/plugins.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('assets/site/css/styles.css')); ?>" rel="stylesheet">
    </head><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/layouts/site/blocks/head.blade.php ENDPATH**/ ?>