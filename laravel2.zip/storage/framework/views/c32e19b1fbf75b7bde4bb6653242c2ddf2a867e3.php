<div class="container">
    <div class="">
        <div class="row m-0  w-100">
            <div class="col-12">
                <div class="fv-row fv-plugins-icon-container">
                    <label class="fs-6 fw-semibold form-label mt-3">
                        <span class="required"> عنوان  </span>
                        <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                    </label>
                    <input type="text" class="form-control form-control-solid" name="title" value="<?php if(isset($data)): ?> <?php echo e(@$data->title); ?>   <?php else: ?> <?php echo e(@old('title')); ?> <?php endif; ?>" style="background:darkgray ;">
                    <div class="fv-plugins-message-container invalid-feedback"></div>
                </div>
            </div>
          

        </div>

        <div class="row m-0  w-100">
            <div class="col-6 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">لینک توییتر</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="twitter" value="<?php if(isset($data)): ?> <?php echo e(@$data->twitter); ?>   <?php else: ?> <?php echo e(@old('twitter')); ?> <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="col-6 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">لینک اینستاگرام</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="instagram" value="<?php if(isset($data)): ?> <?php echo e(@$data->instagram); ?>  <?php else: ?> <?php echo e(@old('instagram')); ?>   <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
        </div>

        <div class="row  m-0  w-100">
        <div class="col-6 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">لینک لینکدین</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="linkedin" value="<?php if(isset($data)): ?> <?php echo e(@$data->instagram); ?>  <?php else: ?> <?php echo e(@old('instagram')); ?>   <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
            <div class="col-6 fv-row fv-plugins-icon-container">
                <label class="fs-12 fw-semibold form-label mt-3">
                    <span class="required">لینک فیسبوک</span>
                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                </label>
                <input type="text" class="form-control form-control-solid" name="facebook" value="<?php if(isset($data)): ?> <?php echo e(@$data->instagram); ?>  <?php else: ?> <?php echo e(@old('instagram')); ?>   <?php endif; ?>" style="background:darkgray ;">
                <div class="fv-plugins-message-container invalid-feedback"></div>
            </div>
        </div>
       


        <div class="fv-row mb-7">
            <label class="fs-6 fw-semibold form-label mt-3">
                <span>توضیحات</span>
                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
            </label>
            <textarea class="form-control ckeditor" name="description" style="background:darkgray ;"> <?php if(isset($data)): ?> <?php echo e(@$data->description); ?>     <?php else: ?> <?php echo e(@old('description')); ?>       <?php endif; ?></textarea>
        </div>
        <div class="form-group mb-3">
                          <label for="example-fileinput"> انتخاب عکس </label>
                          <img src="<?php echo e(asset('assets/upload/'.@$data->image)); ?>" alt=""  style="width:150 ; height:100px">
                          <input type="file" name="image" id="example-fileinput" class="form-control-file">
                        </div>
        
        <br>
        <div class="save">
            <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
        </div>

    </div>
</div><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/about_us/form.blade.php ENDPATH**/ ?>