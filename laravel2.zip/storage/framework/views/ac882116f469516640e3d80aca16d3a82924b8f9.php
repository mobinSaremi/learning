
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
افزودن عضو
<?php $__env->stopSection(); ?>
<form method="POST" action="<?php echo e(route('about_us.add')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<?php echo $__env->make('admin.about_us.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/about_us/add.blade.php ENDPATH**/ ?>