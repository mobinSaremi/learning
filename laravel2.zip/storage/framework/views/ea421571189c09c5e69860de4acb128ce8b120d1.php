
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
 لیست نظرات محصولات
<?php $__env->stopSection(); ?>
<div class="container p-2">
    <div class="card mb-5 mb-xl-8">
        <!--begin::Header-->
        <div class="card-header border-0 pt-5">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bold fs-3 mb-1">  نظرات محصولات</span>
            </h3>
           
        </div>
        <!--end::Header-->
        <!--begin::Body-->
        <div class="card-body py-3">
            <!--begin::Table container-->
            <div class="table-responsive">
                <!--begin::Table-->
                <table class="table align-middle gs-0 gy-4">
                    <!--begin::Table head-->
                    <thead>
                        <tr class="fw-bold text-muted bg-light">
                            <th>شماره</th>
                            <th>نام و نام خانوادگی</th>
                            <th>ایمیل</th>
                            <th>وضعیت نمایش</th>
                            <th>عملیات</th>

                        </tr>
                    </thead>
                    <!--end::Table head-->
                    <!--begin::Table body-->
                    <tbody>
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($comment->id); ?></td>
                            <td>
                              <?php echo e($comment->name); ?>

                            </td>
                            
                           <td><?php echo e($comment->email); ?></td>
                           
                          
                            <td>
                                
                            <?php if($comment->status == 1): ?> <label class="text-success" for="">خوانده شده </label> <?php else: ?> <label class="text-danger" for=""> خوانده نشده</label> <?php endif; ?>
                            </td>
                           <td>
                            

                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo e($comment->id); ?>">
                            نمایش
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="staticBackdrop<?php echo e($comment->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="staticBackdropLabel">کامنت</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php echo e($comment->comment); ?>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">بستن</button>
                                    <?php if($comment->status ==0): ?>
                                    <a class="btn btn-info" href="<?php echo e(route('comment.update',['id'=>$comment->id])); ?>" >نمایش داده شود</a>
                                    <?php else: ?>
                                    <a class="btn btn-info" href="<?php echo e(route('comment.update',['id'=>$comment->id])); ?>" >نمایش داده نشود</a>
                                    <?php endif; ?>
                                    
                                </div>
                                </div>
                            </div>
                            </div>

                            <a class="btn btn-danger" href="<?php echo e(route('comment.delete',['id'=>$comment->id])); ?>" style="width: 80px;">حذف</a>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                        </tr>
                    </tbody>
                    <!--end::Table body-->
                </table>
                <!--end::Table-->
            </div>
            <!--end::Table container-->
        </div>
        <!--begin::Body-->

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/comment/productlist.blade.php ENDPATH**/ ?>