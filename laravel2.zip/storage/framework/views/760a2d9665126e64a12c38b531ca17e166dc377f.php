
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
تنظیمات
<?php $__env->stopSection(); ?>
<div class="col-12">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active text-dark " id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">تنظیمات</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link  text-dark" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="true">درباره ما</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link  text-dark" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="true">تکست ها</button>
        </li>
    </ul>
    <div class="tab-content  p-3" id="myTabContent">
        <div class="tab-pane fade show active  pt-3" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
            <form method="POST" action="<?php echo e(route('admin.setting.list',['id'=>$data->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row m-0  w-100">
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">عنوان سئو</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="title_seo" value="<?php if(isset($data)): ?> <?php echo e(@$data->title_seo); ?>    <?php else: ?> <?php echo e(@old('title_seo')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">آدرس</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="address" value="<?php if(isset($data)): ?> <?php echo e(@$data->address); ?>    <?php else: ?> <?php echo e(@old('address')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>

                    </div>
                    <div class="row m-0  w-100">
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">آدرس توییتر</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="twitter_link" value="<?php if(isset($data)): ?> <?php echo e(@$data->twitter_link); ?>    <?php else: ?> <?php echo e(@old('twitter_link')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">شماره تلفن</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="number_phone" value="<?php if(isset($data)): ?> <?php echo e(@$data->number_phone); ?>    <?php else: ?> <?php echo e(@old('number_phone')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                    </div>
                    <div class="row m-0  w-100">
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                                <span class="required">آدرس فیسبوک</span>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="facebook_link" value="<?php if(isset($data)): ?> <?php echo e(@$data->facebook_link); ?>    <?php else: ?> <?php echo e(@old('facebook_link')); ?>   <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">آدرس اینستاگرام</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="instagram_link" value="<?php if(isset($data)): ?> <?php echo e(@$data->instagram_link); ?>    <?php else: ?> <?php echo e(@old('instagram_link')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                    </div>
                    <div class="row  m-0  w-100">
                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">آدرس لینکدین</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="linkedin_link" value="<?php if(isset($data)): ?> <?php echo e(@$data->linkedin_link); ?>    <?php else: ?> <?php echo e(@old('linkedin_link')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>

                        <div class="col-6 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">آدرس ایمیل</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="email" value="<?php if(isset($data)): ?> <?php echo e(@$data->email); ?>    <?php else: ?> <?php echo e(@old('email')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                    </div>
                    <div class="row m-0  w-100">
                        <div class="fv-row mb-7">
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span>توضیحات سئو</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                            </label>
                            <textarea class="form-control  ckeditor" name="description_seo" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->description_seo); ?>     <?php else: ?> <?php echo e(@old('description_seo')); ?>       <?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="row m-0  w-100">
                        <div class="form-group mb-3">
                            <label for="example-fileinput"> انتخاب لوگو </label>
                            <img src="<?php echo e(asset('assets/upload/'.@$data->logo)); ?>" alt="" style="width:200px; height:125px">
                            <input type="file" name="logo" id="example-fileinput" class="form-control-file">
                        </div>

                        <div class="save">
                            <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="tab-pane fade pt-3" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
            <div class="row  w-100 m-0">
                <div class="col-12 px-lx-5 px-lg-5 px-md-3 px-sm-2">
                    <div class="container">
                        <div class="">
                            <form method="POST" action="<?php echo e(route('admin.setting.list',['id'=>$data->id])); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row m-0  w-100">
                                    <div class="col-12">
                                        <div class="fv-row fv-plugins-icon-container">
                                            <label class="fs-6 fw-semibold form-label mt-3">
                                                <span class="required"> عنوان </span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                                            </label>
                                            <input type="text" class="form-control form-control-solid" name="about_us_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->about_us_title); ?>   <?php else: ?> <?php echo e(@old('about_us_title')); ?> <?php endif; ?>" style="background:#dddddd ;">
                                        </div>
                                    </div>
                                </div>
                                <div class="fv-row mb-7">
                                    <label class="fs-6 fw-semibold form-label mt-3">
                                        <span>توضیحات</span>
                                        <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                                    </label>
                                    <textarea class="form-control ckeditor" name="about_us_description" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->about_us_description); ?>     <?php else: ?> <?php echo e(@old('about_us_description')); ?>       <?php endif; ?></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-fileinput"> انتخاب عکس </label>
                                    <img src="<?php echo e(asset('assets/upload/'.@$data->image)); ?>" style="width:200px; height:125px" alt="">
                                    <input type="file" name="image" id="example-fileinput" class="form-control-file">
                                </div>
                                <br>
                                <div class="save">
                                    <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade   pt-3" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
            <form method="POST" action="<?php echo e(route('admin.setting.list',['id'=>$data->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row m-0  w-100">
                        <div class="col-12 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">عنوان مقاله </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="blog_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->blog_title); ?>    <?php else: ?> <?php echo e(@old('blog_title')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="fv-row mb-7">
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span>توضیحات مقاله</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                            </label>
                            <textarea class="form-control  ckeditor" name="blog_description" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->blog_description); ?>     <?php else: ?> <?php echo e(@old('blog_description')); ?>       <?php endif; ?></textarea>
                        </div>
                    </div>

                    <hr>

                    <div class="row m-0  w-100">
                        <div class="col-12 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">عنوان تیم ما </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="personal_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->personal_title); ?>    <?php else: ?> <?php echo e(@old('personal_title')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="fv-row mb-7">
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span>توضیحات تیم ما</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                            </label>
                            <textarea class="form-control  ckeditor" name="personal_description" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->personal_description); ?>     <?php else: ?> <?php echo e(@old('personal_description')); ?>       <?php endif; ?></textarea>
                        </div>
                    </div>

                    <hr>

                    <div class="row m-0  w-100">
                        <div class="col-12 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">عنوان محصولات </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="product_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->product_title); ?>    <?php else: ?> <?php echo e(@old('product_title')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="fv-row mb-7">
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span>توضیحات محصولات </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                            </label>
                            <textarea class="form-control  ckeditor" name="product_description" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->product_description); ?>     <?php else: ?> <?php echo e(@old('product_description')); ?>       <?php endif; ?></textarea>
                        </div>
                    </div>

                    <hr>

                    <div class="row m-0  w-100">
                        <div class="col-12 fv-row fv-plugins-icon-container">
                            <label class="fs-12 fw-semibold form-label mt-3">
                                <span class="required">عنوان پیشنهادات </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's name." data-kt-initialized="1"></i>
                            </label>
                            <input type="text" class="form-control form-control-solid" name="suggestion_title" value="<?php if(isset($data)): ?> <?php echo e(@$data->suggestion_title); ?>    <?php else: ?> <?php echo e(@old('suggestion_title')); ?>  <?php endif; ?>" style="background:#dddddd ;">
                            <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                        <div class="fv-row mb-7">
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span>توضیحات پیشنهادات </span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter any additional notes about the contact (optional)." data-kt-initialized="1"></i>
                            </label>
                            <textarea class="form-control  ckeditor" name="suggestion_description" style="background:#dddddd ;"> <?php if(isset($data)): ?> <?php echo e(@$data->suggestion_description); ?>     <?php else: ?> <?php echo e(@old('suggestion_description')); ?>       <?php endif; ?></textarea>
                        </div>
                    </div>
                    <div class="row m-0  w-100">
                        <div class="save">
                            <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/setting/edit.blade.php ENDPATH**/ ?>