
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
ثبت نام
<?php $__env->stopSection(); ?>
<!DOCTYPE html>
<html lang="en">

<body>
  <div class="page-title-wrap pt-img-wrap" style="background:url('<?php echo e(asset('assets/upload/1e530ca2d79d91f27bc3d8e0529f1f4d.jpg')); ?>') no-repeat;">
    <div class="container">
      <div class="col-lg-12 col-md-12">
        <div class="pt-caption text-center mt-5">
          <h1> ثبت نام</h1>
          <p><a href="<?php echo e(route('index')); ?>">خانه</a><span class="current-page">ثبت نام</span></p>
        </div>
      </div>
    </div>
  </div>
  <section class="vh-100" style="background-color: #eee;">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100 ">
        <div class="col-lg-12 col-xl-11 ">
          <div class="card text-black" style="border-radius: 25px;">
            <div class="card-body p-md-3 ">
              <div class="row justify-content-center">
                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                  <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">فرم ثبت نام </p>

                  <form class="mx-1 mx-md-4" method="Post" action="<?php echo e(route('postregister')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product_id); ?>">
                    <div class="d-flex flex-row align-items-center mb-4">
                      <div class="form-outline d-flex  mb-0">
                        <input type="text" name="fullname" id="form3Example1c" class="form-control" placeholder="نام و نام خانوادگی" />
                      </div>
                    </div>
                    <div class="d-flex flex-row align-items-center mb-4">
                      <div class="form-outline d-flex  mb-0">
                        <input type="email" name="email" id="form3Example3c" class="form-control" placeholder="ایمیل" />
                      </div>
                    </div>
                    <div class="d-flex flex-row align-items-center mb-4">
                      <div class="form-outline d-flex  mb-0">
                        <input type="password" name="password" id="form3Example4c" class="form-control" placeholder="رمز"   />
                      </div>
                    </div>
                    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                      <button type="submit" class="btn btn-primary btn-lg">ثبت نام</button>
                    </div>

                  </form>

                </div>
                <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                  <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp" class="img-fluid" alt="Sample image">

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/register.blade.php ENDPATH**/ ?>