<div class="container">
    <div class="row m-0  w-100">
       

    <div class="form-group mb-3">
                          <label for="example-fileinput"> انتخاب عکس </label>
                          <img src="<?php echo e(asset('assets/upload/'.@$data->image)); ?>" alt=""   style="width:150 ; height:100px">
                          <input type="file" name="image" id="example-fileinput" class="form-control-file">
                        </div>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
        

        <div class="">
            <div class="">


            </div>
            <br>
            <div class="save">
                <button class="btn btn-primary" type="submit" style="margin: 0 auto;display:flex">ذخیره</button>
            </div>
        </div>
    </div><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/image/form.blade.php ENDPATH**/ ?>