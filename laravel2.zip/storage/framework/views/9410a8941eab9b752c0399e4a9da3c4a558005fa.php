<section class="gray">
				<div class="container">
				
					<div class="row">
						<div class="col text-center">
							<div class="sec-heading mx-auto">
								<h2></h2>
								<p></p>
							</div>
						</div>
					</div>
					
					<div class="row">
						<?php $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suggestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<div class="col-lg-4 col-md-4">
							<div class="testimonial-wrap aos-init aos-animate" data-aos="fade-up" data-aos-duration="1200">
								<i class="fa fa-quote-left"></i>
								<p><?php echo $suggestion->description; ?></p>
								
								<div class="client-thumb-box">
									<div class="client-thumb-content">
										<div class="client-thumb">
											<img src="<?php echo e(asset('assets/upload/'.$suggestion->image)); ?>" class="img-responsive img-circle" alt="">
										</div>
										<h5 class="mb-0"><?php echo e($suggestion->name); ?> </h5>
										<span class="small-font"><?php echo e($suggestion->post); ?> </span>
									</div>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</div>
					
				</div>
			</section><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/site/blocks/suggestion.blade.php ENDPATH**/ ?>