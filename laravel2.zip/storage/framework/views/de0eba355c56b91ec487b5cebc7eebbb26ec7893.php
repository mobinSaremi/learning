<section class="bg--dark">
				<div class="container">
				
					<div class="row">
						<div class="col text-center">
							<div class="sec-heading mx-auto">
								<h2 class="font-2 font-normal"> <?php echo e($setting_site->personal_title); ?> </h2>
								<p><?php echo $setting_site->personal_description; ?></p>
							</div>
						</div>
					</div>
					
					<div class="row">
						<?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-4 col-sm-6 mb-4">
							<div class="our-team" data-aos="fade-up" data-aos-duration="1200">
								<img src="<?php echo e(asset('assets/upload/'.$personal->avatar)); ?>" class="img-responsive" alt="" />
								<h4><?php echo e($personal->fullname); ?> </h4>
								<span class="designation bg-success"><?php echo e($personal->post); ?> </span>
								<p><?php echo $personal->explanation; ?></p>
								<ul class="our-team-profile">
								<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
									<li><a href="http://www.twitter.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
									<li><a href="http://www.linkedin.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="https://www.instagram.com/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				
				</div>
			</section><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/blocks/personal.blade.php ENDPATH**/ ?>