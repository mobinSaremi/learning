
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
 <?php echo e($setting_site->title_seo); ?> 
<?php $__env->stopSection(); ?>
<!-- ============================ Banner Video Start ================================== -->
<?php echo $__env->make('site.blocks.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- ============================ Banner Video End ================================== -->
			
			<!-- ============================ What We Do Start ================================== -->
			<?php echo $__env->make('site.blocks.article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="clearfix"></div>
			<!-- ============================ What We Do End ================================== -->
			
			<!-- ============================ Image Block Start ================================== -->
			<section class="p-0">
				<div class="container-fluid p-0">
					<div class="imagebg height-60" data-overlay="5">
						<div class="bg-img-holder" style="background: url('<?php echo e(asset('assets/site/img/bn7.jpg')); ?>'); opacity: 1;">
							<img alt="background" src="<?php echo e(asset('assets/site/img/bn7.jpg')); ?>">
						</div>
						<div class="container pos-vertical-center">
							<div class="row text-center justify-content-center">
								<div class="col-md-10">
									<blockquote>"لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون."</blockquote>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- ============================ Image Block End ================================== -->
			
			<!-- ============================ Our Team Start ================================== -->
			<?php echo $__env->make('site.blocks.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="clearfix"></div>
			<!-- ============================ Our Team End ================================== -->
			
			<!-- ============================ Our Prices Start ================================== -->
			<?php echo $__env->make('site.blocks.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="clearfix"></div>
			<!-- ============================ Our Prices End ================================== -->
			
			<!-- ============================ Our Testimonial Start ================================== -->
			<?php echo $__env->make('site.blocks.suggestion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="clearfix"></div>
			<!-- ============================ Our Testimonial End ================================== -->
<?php echo $__env->make('layouts.site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/index.blade.php ENDPATH**/ ?>