
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
درباره ما
<?php $__env->stopSection(); ?>
<!DOCTYPE html>
<html lang="en">

<body>

	<div class="page-title-wrap pt-img-wrap" style="background:url('<?php echo e(asset('assets/upload/1e530ca2d79d91f27bc3d8e0529f1f4d.jpg')); ?>') no-repeat;">
		<div class="container">
			<div class="col-lg-12 col-md-12">
				<div class="pt-caption text-center mt-5">
					<h1>درباره ما</h1>
					<p><a href="<?php echo e(route('index')); ?>">خانه</a><span class="current-page"> درباره ما</span></p>
				</div>
			</div>
		</div>
	</div>
	<section>
		<div class="container">

			<div class="row">

				<div class="col-lg-6 col-md-6">
					<div class="about-content">
						<h2><?php echo e($setting_site->about_us_title); ?></h2>
						<p><?php echo $setting_site->about_us_description; ?></p>
						<ul class="our-team-profile ts-light-bg">
							<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
							<li><a href="http://www.twitter.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
							<li><a href="http://www.linkedin.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="https://www.instagram.com/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-6 col-md-6">
					<img src="<?php echo e(asset('assets/upload/'.$setting_site->image)); ?>" class="img-fluid mx-auto" alt="">
				</div>
			</div>
		</div>
	</section>
	<section>
		<div class="container">

			<div class="row">
				<div class="col text-center">
					<div class="sec-heading mx-auto">
						<h2><?php echo e($setting_site->personal_title); ?> </h2>
						<p><?php echo $setting_site->personal_description; ?></p>
					</div>
				</div>
			</div>

			<div class="row">
				<?php $__currentLoopData = $person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-4 col-sm-6 mb-4">
					<div class="our-team">
						<img src="<?php echo e(asset('assets/upload/'.$personal->avatar)); ?>" class="img-responsive" alt="" />
						<h4><a href="about-2.html#"> <?php echo e($personal->name); ?></a></h4>
						<span class="simple-designation"><?php echo e($personal->post); ?></span>
						<p><?php echo $personal->explanation; ?></p>
						<ul class="our-team-profile">
							<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook"></i></a></li>
							<li><a href="http://www.twitter.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-twitter"></i></a></li>
							<li><a href="http://www.linkedin.com/share?url=<?php echo e(url()->current()); ?>"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="https://www.instagram.com/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

		</div>
	</section>
	</div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/about_us.blade.php ENDPATH**/ ?>