
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
جزئیات محصول
<?php $__env->stopSection(); ?>

<body>
	<div class="page-title-wrap pt-img-wrap" style="background:url('<?php echo e(asset('assets/upload/1e530ca2d79d91f27bc3d8e0529f1f4d.jpg')); ?>') no-repeat;">
		<div class="container">
			<div class="col-lg-12 col-md-12">
				<div class="pt-caption text-center mt-5">
					<h1><?php echo e(@$product->title); ?></h1>
					<p><a href="<?php echo e(route('index')); ?>">خانه</a><span class="current-page">جزئیات محصول</span></p>
				</div>
			</div>
		</div>
	</div>
	<section>
		<div class="container">

			<div class="row mb-4">
				<div class="col-lg-7 col-md-6 col-sm-12">
					<?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<img src="<?php echo e(asset('assets/upload/'.$img->image)); ?>" class="img-fluid mx-auto mb-2" alt="" />

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="col-lg-5 col-md-6 col-sm-12">
					<div class="portfolio-detail-caption">

						<div class="portfolio-detail-caption-header">
							<h3><?php echo e(@$product->title); ?></h3>
						</div>
						<div class="portfolio-detail-caption-overview">

							<ul class="port-metas mb-3">
								<li><strong>دسته بندی:</strong><?php echo e(@$product->category->title); ?></li>
								<li><strong>قیمت:</strong><?php echo e(number_format(@$product->price)); ?> تومان</li>
							</ul>
							<?php if(Auth::check()): ?>
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap">خرید محصول</button>
							<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="exampleModalLabel">خرید</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<form method="Post" action="<?php echo e(route('checkout')); ?>" enctype="multipart/form-data">
												<?php echo csrf_field(); ?>
												<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
												<input type="hidden" name="payment" value="<?php echo e($product->price); ?>">
												<input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
												<div class="row m-0  w-100">
													<div class=" col-6 form-group">
														<label for="recipient-name" class="col-form-label">نام گیرنده:</label>
														<input type="text" name="fullname" class="form-control" id="recipient-name">
													</div>
													<div class="col-6 form-group">
														<label for="recipient-name" class="col-form-label">شماره تماس :</label>
														<input type="text" name="phone_number" class="form-control" id="recipient-name">
													</div>
												</div>
												<div class="row m-0  w-100">
													<div class="col-12 d-flex">
														<h5>نحوه ارسال:</h5>
														<select class="form-select form-select-lg mb-3 mx-4" name="send">
															<option selected>نحوه ارسال را انتخاب کنید</option>
															<option value="delivery">پیک</option>
															<option value="post	">پست</option>
														</select>
													</div>
												</div>
												<div class="row m-0 w-100">
													<div class="col-12">
														<div class="form-group">
															<label for="message-text" class="col-form-label">آدرس:</label>
															<textarea class="form-control" name="address" id="message-text"></textarea>
														</div>
													</div>
												</div>
												<div class="modal-footer d-flex  justify-content-between">
													<div class="box">
														<button type="button" class="btn btn-secondary mx-1" data-dismiss="modal">لغو</button>
														<button type="submit" class="btn btn-primary"> پرداخت</button>
														
													</div>
													<div class="box2  d-flex ">
														<h6>قیمت:</h6>
															<?php echo e(number_format(@$product->price)); ?> تومان
														</div>

												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<?php else: ?>
							<a href="<?php echo e(url('/site/register?product_id='.$product->id)); ?>" class="btn btn-primary" data-whatever="@getbootstrap">خرید محصول</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			<div class="row mb-5">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<p><?php echo @$product->description; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<h3>محصولات بیشتر</h3>
				</div>
			</div>
			<div class="row" id="portfolio">
				<!-- Single Project -->
				<?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-4 col-sm-12 mb-3">
					<div class="project portfolio-inner">
						<img src="<?php echo e(asset('assets/upload/'.$product->image)); ?>" alt="">
						<div class="label">
							<div class="label-text"> <a href="<?php echo e(route('productdetail',['id'=>$product->id])); ?>" class="text-title"><?php echo e($product->title); ?></a> </div>
							<div class="label-bg"></div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/product/detail.blade.php ENDPATH**/ ?>