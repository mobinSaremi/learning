
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
 فاکتور
<?php $__env->stopSection(); ?>
<!DOCTYPE html>
<html lang="en">

<body>
<div class="page-title-wrap pt-img-wrap" style="background:url('<?php echo e(asset('assets/upload/1e530ca2d79d91f27bc3d8e0529f1f4d.jpg')); ?>') no-repeat;">
		<div class="container">
			<div class="col-lg-12 col-md-12">
				<div class="pt-caption text-center mt-5">
					<p><a href="<?php echo e(route('index')); ?>">خانه</a><span class="current-page">لیست فاکتور ها</span></p>
				</div>
			</div>
		</div>
	</div>
<div class="container p-2">
    <div class="card mb-5 mb-xl-8">
        <!--begin::Header-->
        <div class="card-header border-0 pt-5">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bold fs-3 mb-1"> جدول فاکتور ها</span>
            </h3>
        </div>
        <!--end::Header-->
        <!--begin::Body-->
        <div class="card-body py-3">
            <!--begin::Table container-->
            <div class="table-responsive">
                <!--begin::Table-->
                <table class="table align-middle gs-0 gy-4">
                    <!--begin::Table head-->
                    <thead>
                        <tr class="fw-bold text-muted bg-light">
                            <th>شماره</th>
                            <th>نام نام خانوادگی</th>
                            <th>شماره تماس</th>
                            <th>قیمت</th>
                        </tr>
                    </thead>
                    <!--end::Table head-->
                    <!--begin::Table body-->
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td>
                              <?php echo e($order->fullname); ?>

                            </td>
                            <td><?php echo e($order->phone_number); ?></td>
                           <td><?php echo e(number_format(@$order->payment)); ?> تومان</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                        </tr>
                    </tbody>
                    <!--end::Table body-->
                </table>
                <!--end::Table-->
            </div>
            <!--end::Table container-->
        </div>
        <!--begin::Body-->

    </div>
</div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/site/panel-order.blade.php ENDPATH**/ ?>