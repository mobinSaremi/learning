
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
افزودن ادمین
<?php $__env->stopSection(); ?>
<form method="POST" action="<?php echo e(route('admin.add')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<?php echo $__env->make('admin.admin.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/admin/add.blade.php ENDPATH**/ ?>