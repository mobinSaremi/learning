
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
فاکتور ثبت محصول
<?php $__env->stopSection(); ?>
<div class="container p-2">
    <div class="card mb-5 mb-xl-8">
        <div class="card-header border-0 pt-5">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bold fs-3 mb-1"> فاکتور </span>
            </h3>
        </div>
        <div class="card-body py-3">
            <div class="table-responsive">
                <table class="table align-middle gs-0 gy-4">
                    <thead>
                        <tr class="fw-bold text-muted bg-light">
                            <th>شماره</th>
                            <th>نام و نام خانوادگی</th>
                            <th>شماره تماس</th>
                            <th>وضعیت نمایش</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(@$order->id); ?></td>
                            <td>
                                <?php echo e(@$order->fullname); ?>

                            </td>
                            <td><?php echo e(@$order->phone_number); ?></td>
                            <td>
                                <?php if($order->order_status =='paying'): ?> <label class="text-success" for=""> پرداخت شد </label> <?php else: ?> <label class="text-danger" for=""> لغو شد</label> <?php endif; ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo e($order->id); ?>">
                                    آدرس
                                </button>
                                <div class="modal fade" id="staticBackdrop<?php echo e($order->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">آدرس</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?php echo e($order->address); ?>

                                            </div>
                                            <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">بستن</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a class="btn btn-danger" onclick="return confirm('آیا از حذف اطلاعات مطمئن هستید؟');" href="<?php echo e(route('admin.order.list.delete',['id'=>$order->id])); ?>" style="width: 80px;">حذف</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\rahweb\projects\laravel\resources\views/admin/order/list.blade.php ENDPATH**/ ?>