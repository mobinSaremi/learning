
<html>

<head>
    <meta charset="utf-8">
    <script  src="<?php echo e(asset('assets/admin/js/sweetalert.min.js')); ?>"></script>
</head>

<body>
<?php echo $__env->make('layouts.admin.blocks.message-swal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <center>
        
        <div style=" background:#aaa ;    width: 400px;height:230px ; border:2px solid  #000; border-radius:20px ; margin-top: 100px;">
            <h3>login</h3>
            <form method="post" action="<?php echo e(route('login')); ?>" ><br/><br/>
            <?php echo csrf_field(); ?>
                <label>  ایمیل   :</label>
                <input  type="text" name="email" placeholder="ایمیل "><br/><br/>
                <label>پسورد  : </label>
                <input     type="password" name="password" placeholder="پسورد"><br/><br/>
                <input  type="submit"   value="ارسال">
            </form>

        </div>
    </center>

</body>

</html>
<?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/auth/login-form.blade.php ENDPATH**/ ?>