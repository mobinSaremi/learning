<div class="topbar" id="top">
	<div class="header exchange-logo">
		<div class="container po-relative">
			<nav class="navbar navbar-expand-lg header-nav-bar">
				<a href="<?php echo e(route('index')); ?>" class="navbar-brand">
					<img src="<?php echo e(asset('assets/upload/'.$setting_site->logo)); ?>" class="default-logo" alt="Themex">
					
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation"><span class="ti-align-right"></span></button>
				<div class="collapse navbar-collapse hover-dropdown font-14 ml-auto" id="navigation">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item dropdown nav-dropdown">
							<a class="nav-link" href="<?php echo e(route('index')); ?>" id="nav-dropdown" data-toggle="" aria-haspopup="true" aria-expanded="false">خانه </a>

						</li>

						<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">دسته بندی <i class="fa fa-angle-down m-l-5"></i></a>
										<ul class="b-none dropdown-menu font-14 animated fadeInUp">
											<?php $__currentLoopData = $categor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if(count($cat->childs) > 0): ?>
												
												
												<li class="dropdown-submenu"> <a class="dropdown-toggle dropdown-item" href="javascript:void(0)" aria-haspopup="true" aria-expanded="false"> <?php echo e($cat->title); ?> <i class="fa fa-angle-right ml-auto"></i></a>
													<ul class="dropdown-menu menu-right font-14 b-none animated flipInY">
															<?php $__currentLoopData = $cat->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																
																<a class="dropdown-item" href="<?php echo e(route('productdetail',['id'=>$cat->id])); ?>"><?php echo e(@$child->title); ?></a>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</li>
												<?php else: ?>
													<a class="dropdown-toggle dropdown-item" href="<?php echo e(route('productdetail',['id'=>$cat->id])); ?>"><?php echo e(@$cat->title); ?> </i></a>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</li>

						


						</li>
						<li class="nav-item dropdown nav-dropdown">
							<a class="nav-link" href="<?php echo e(route('getcontact')); ?>" id="nav-dropdown" data-toggle="" aria-haspopup="true" aria-expanded="false">تماس با ما</a>

						</li>
						<li class="nav-item dropdown nav-dropdown">
							<a class="nav-link" href="<?php echo e(route('bloglist')); ?>" id="nav-dropdown" data-toggle="" aria-haspopup="true" aria-expanded="false">مقالات</a>

						</li>
						<li class="nav-item dropdown nav-dropdown">
							<a class="nav-link" href="<?php echo e(route('newslist')); ?>" id="nav-dropdown" data-toggle="" aria-haspopup="true" aria-expanded="false">اخبار</a>

						</li>
						<li class="nav-item dropdown nav-dropdown">
							<a class="nav-link" href="<?php echo e(route('getabout')); ?>" id="nav-dropdown" data-toggle="" aria-haspopup="true" aria-expanded="false">درباره ما</a>

						</li>

					</ul>

					

				</div>
			</nav>
		</div>
	</div>
</div><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/layouts/site/blocks/header.blade.php ENDPATH**/ ?>