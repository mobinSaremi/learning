
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
داشبورد
<?php $__env->stopSection(); ?>

<div class="container ">
    <div class="box mt-3">
        <div class="row  m-0  w-100  justify-content-center ">
            <?php $num_news = App\Models\News::where('status', 1)->count(); ?>
            <div class="col-4  m-3 " style="background:#ccc ;padding:20px;   border-radius: 20px;">
                <h3>اخبار</h3>
                <p>(<?php echo e($num_news); ?>)</p>
            </div>

            <?php $num_comment = App\Models\Comment::where('status', 1)->count(); ?>
            <div class="col-4  m-3" style="background:#bbc ;padding:20px   ;  border-radius: 20px;">
                <h3>نظرات</h3>
                <p>(<?php echo e($num_comment); ?>)</p>
            </div>
        </div>

        <div class="row m-0 w-100   justify-content-center">
            <?php $num_product = App\Models\Product::where('status', 1)->count(); ?>
            <div class="col-4  m-3" style="background:#aac ;padding:20px ;    border-radius: 20px;">
                <h3>محصولات</h3>
                <p>(<?php echo e($num_product); ?>)</p>
            </div>
            <?php $num_contact = App\Models\Contact_us::where('status', 1)->count(); ?>
            <div class="col-4  m-3" style="background:#aaa ;padding:20px ;    border-radius: 20px;">
                <h3>تماس باما</h3>
                <p>(<?php echo e($num_contact); ?>)</p>
            </div>
        </div>
    </div>





</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mobin\ره وب\projects\laravel\resources\views/admin/main.blade.php ENDPATH**/ ?>